/*
 * ���� ����
 */
package util;

import java.awt.Color;

public class ColorSet {

  public static final Color signUpButtonColor = new Color(94, 82, 82);

  public static final Color BackButtonColor = new Color(94, 82, 82);

  public static final Color talkBackgroundColor = new Color(233, 242, 255);

  public static final Color messageSendButtonColor = new Color(209, 206, 206);


}
